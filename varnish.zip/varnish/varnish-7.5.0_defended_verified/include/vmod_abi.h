/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run include/generate.py instead.
 */

#define VMOD_ABI_Version "Varnish 7.5.0 eef25264e5ca5f96a77129308edb83ccf84cb1b1"
