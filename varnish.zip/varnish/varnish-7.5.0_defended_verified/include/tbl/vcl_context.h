/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run lib/libvcc/generate.py instead.
 */

/*lint -save -e525 -e539 */

VCL_CTX(vcl_recv,RECV)
VCL_CTX(vcl_pipe,PIPE)
VCL_CTX(vcl_pass,PASS)
VCL_CTX(vcl_hash,HASH)
VCL_CTX(vcl_purge,PURGE)
VCL_CTX(vcl_miss,MISS)
VCL_CTX(vcl_hit,HIT)
VCL_CTX(vcl_deliver,DELIVER)
VCL_CTX(vcl_synth,SYNTH)
VCL_CTX(vcl_backend_fetch,BACKEND_FETCH)
VCL_CTX(vcl_backend_response,BACKEND_RESPONSE)
VCL_CTX(vcl_backend_error,BACKEND_ERROR)
VCL_CTX(vcl_init,INIT)
VCL_CTX(vcl_fini,FINI)
VCL_CTX(backend, TASK_B)
VCL_CTX(client, TASK_C)
VCL_CTX(housekeeping, TASK_H)/*lint -restore */


#undef VCL_CTX
