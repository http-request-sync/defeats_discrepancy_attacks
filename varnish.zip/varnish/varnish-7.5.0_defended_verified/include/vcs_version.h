/* eef25264e5ca5f96a77129308edb83ccf84cb1b1 */
/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run include/generate.py instead.
 */

#define VCS_Version "eef25264e5ca5f96a77129308edb83ccf84cb1b1"
