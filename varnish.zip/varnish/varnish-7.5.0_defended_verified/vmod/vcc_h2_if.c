/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_h2.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_h2_if.h"
#include "vmod_abi.h"


typedef VCL_BOOL td_vmod_h2_is(VRT_CTX);
typedef VCL_DURATION td_vmod_h2_rapid_reset(VRT_CTX,
    struct VARGS(rapid_reset)*);
typedef VCL_INT td_vmod_h2_rapid_reset_limit(VRT_CTX,
    struct VARGS(rapid_reset_limit)*);
typedef VCL_DURATION td_vmod_h2_rapid_reset_period(VRT_CTX,
    struct VARGS(rapid_reset_period)*);
typedef VCL_REAL td_vmod_h2_rapid_reset_budget(VRT_CTX);

struct Vmod_vmod_h2_Func {
	td_vmod_h2_is			*f_is;
	td_vmod_h2_rapid_reset		*f_rapid_reset;
	td_vmod_h2_rapid_reset_limit	*f_rapid_reset_limit;
	td_vmod_h2_rapid_reset_period	*f_rapid_reset_period;
	td_vmod_h2_rapid_reset_budget	*f_rapid_reset_budget;
};

/*lint -esym(754, Vmod_vmod_h2_Func::*) */

static const struct Vmod_vmod_h2_Func Vmod_vmod_h2_Func = {
	.f_is =				vmod_is,
	.f_rapid_reset =		vmod_rapid_reset,
	.f_rapid_reset_limit =		vmod_rapid_reset_limit,
	.f_rapid_reset_period =		vmod_rapid_reset_period,
	.f_rapid_reset_budget =		vmod_rapid_reset_budget,

};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"h2\", "
	"    \"Vmod_vmod_h2_Func\", "
	"    \"ec5085a739ca2da36d9a874e57b6300a3bb1ec3525d6be53057e04c6756c3691\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_h2_##a\", "
	"    \"#define VENUM(a) enum_vmod_h2_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_BOOL td_vmod_h2_is(VRT_CTX);\", "
	"    \"\", "
	"    \"struct VARGS(rapid_reset) {\", "
	"    \"\\tchar\\t\\t\\tvalid_threshold;\", "
	"    \"\\tVCL_DURATION\\t\\tthreshold;\", "
	"    \"};\", "
	"    \"typedef VCL_DURATION td_vmod_h2_rapid_reset(VRT_CTX,\", "
	"    \"    struct VARGS(rapid_reset)*);\", "
	"    \"\", "
	"    \"struct VARGS(rapid_reset_limit) {\", "
	"    \"\\tchar\\t\\t\\tvalid_number;\", "
	"    \"\\tVCL_INT\\t\\t\\tnumber;\", "
	"    \"};\", "
	"    \"typedef VCL_INT td_vmod_h2_rapid_reset_limit(VRT_CTX,\", "
	"    \"    struct VARGS(rapid_reset_limit)*);\", "
	"    \"\", "
	"    \"struct VARGS(rapid_reset_period) {\", "
	"    \"\\tchar\\t\\t\\tvalid_duration;\", "
	"    \"\\tVCL_DURATION\\t\\tduration;\", "
	"    \"};\", "
	"    \"typedef VCL_DURATION td_vmod_h2_rapid_reset_period(VRT_CTX,\", "
	"    \"    struct VARGS(rapid_reset_period)*);\", "
	"    \"typedef VCL_REAL td_vmod_h2_rapid_reset_budget(VRT_CTX);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_h2_Func {\", "
	"    \"\\ttd_vmod_h2_is\\t\\t\\t*f_is;\", "
	"    \"\\ttd_vmod_h2_rapid_reset\\t\\t*f_rapid_reset;\", "
	"    \"\\ttd_vmod_h2_rapid_reset_limit\\t*f_rapid_reset_limit;\", "
	"    \"\\ttd_vmod_h2_rapid_reset_period\\t*f_rapid_reset_period;\", "
	"    \"\\ttd_vmod_h2_rapid_reset_budget\\t*f_rapid_reset_budget;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_h2_Func Vmod_vmod_h2_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"is\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_h2_Func.f_is\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"rapid_reset\", "
	"    [ "
	"      [ "
	"        \"DURATION\" "
	"      ], "
	"      \"Vmod_vmod_h2_Func.f_rapid_reset\", "
	"      \"struct arg_vmod_h2_rapid_reset\", "
	"      [ "
	"        \"DURATION\", "
	"        \"threshold\", "
	"        null, "
	"        null, "
	"        true "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"rapid_reset_limit\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_h2_Func.f_rapid_reset_limit\", "
	"      \"struct arg_vmod_h2_rapid_reset_limit\", "
	"      [ "
	"        \"INT\", "
	"        \"number\", "
	"        null, "
	"        null, "
	"        true "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"rapid_reset_period\", "
	"    [ "
	"      [ "
	"        \"DURATION\" "
	"      ], "
	"      \"Vmod_vmod_h2_Func.f_rapid_reset_period\", "
	"      \"struct arg_vmod_h2_rapid_reset_period\", "
	"      [ "
	"        \"DURATION\", "
	"        \"duration\", "
	"        null, "
	"        null, "
	"        true "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"rapid_reset_budget\", "
	"    [ "
	"      [ "
	"        \"REAL\" "
	"      ], "
	"      \"Vmod_vmod_h2_Func.f_rapid_reset_budget\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_h2_Data) */
/*lint -esym(759, Vmod_h2_Data) */
/*lint -esym(765, Vmod_h2_Data) */

extern const struct vmod_data Vmod_h2_Data;

const struct vmod_data Vmod_h2_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"ec5085a739ca2da36d9a874e57b6300a3bb1ec3525d6be53057e04c6756c3691",
	.name =		"h2",
	.func_name =	"Vmod_vmod_h2_Func",
	.func =		&Vmod_vmod_h2_Func,
	.func_len =	sizeof(Vmod_vmod_h2_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
