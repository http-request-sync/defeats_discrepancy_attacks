/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_purge.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_purge_if.h"
#include "vmod_abi.h"


typedef VCL_INT td_vmod_purge_hard(VRT_CTX);
typedef VCL_INT td_vmod_purge_soft(VRT_CTX, VCL_DURATION,
    VCL_DURATION, VCL_DURATION);

struct Vmod_vmod_purge_Func {
	td_vmod_purge_hard		*f_hard;
	td_vmod_purge_soft		*f_soft;
};

/*lint -esym(754, Vmod_vmod_purge_Func::*) */

static const struct Vmod_vmod_purge_Func Vmod_vmod_purge_Func = {
	.f_hard =			vmod_hard,
	.f_soft =			vmod_soft,

};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"purge\", "
	"    \"Vmod_vmod_purge_Func\", "
	"    \"6727e5c4830d041f2964db616ad639343047f793ddecfbfc9c7d73fdfbf82c18\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_purge_##a\", "
	"    \"#define VENUM(a) enum_vmod_purge_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_INT td_vmod_purge_hard(VRT_CTX);\", "
	"    \"typedef VCL_INT td_vmod_purge_soft(VRT_CTX, VCL_DURATION,\", "
	"    \"    VCL_DURATION, VCL_DURATION);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_purge_Func {\", "
	"    \"\\ttd_vmod_purge_hard\\t\\t*f_hard;\", "
	"    \"\\ttd_vmod_purge_soft\\t\\t*f_soft;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_purge_Func Vmod_vmod_purge_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"hard\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_purge_Func.f_hard\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"vcl_hit\", "
	"      \"vcl_miss\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"soft\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_purge_Func.f_soft\", "
	"      \"\", "
	"      [ "
	"        \"DURATION\", "
	"        \"ttl\", "
	"        \"0\" "
	"      ], "
	"      [ "
	"        \"DURATION\", "
	"        \"grace\", "
	"        \"-1\" "
	"      ], "
	"      [ "
	"        \"DURATION\", "
	"        \"keep\", "
	"        \"-1\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"vcl_hit\", "
	"      \"vcl_miss\" "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_purge_Data) */
/*lint -esym(759, Vmod_purge_Data) */
/*lint -esym(765, Vmod_purge_Data) */

extern const struct vmod_data Vmod_purge_Data;

const struct vmod_data Vmod_purge_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"6727e5c4830d041f2964db616ad639343047f793ddecfbfc9c7d73fdfbf82c18",
	.name =		"purge",
	.func_name =	"Vmod_vmod_purge_Func",
	.func =		&Vmod_vmod_purge_Func,
	.func_len =	sizeof(Vmod_vmod_purge_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
