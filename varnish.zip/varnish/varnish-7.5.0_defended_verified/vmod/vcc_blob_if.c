/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_blob.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_blob_if.h"
#include "vmod_abi.h"

VCL_ENUM VENUM(BASE64) = "BASE64";
VCL_ENUM VENUM(BASE64CF) = "BASE64CF";
VCL_ENUM VENUM(BASE64URL) = "BASE64URL";
VCL_ENUM VENUM(BASE64URLNOPAD) = "BASE64URLNOPAD";
VCL_ENUM VENUM(DEFAULT) = "DEFAULT";
VCL_ENUM VENUM(HEX) = "HEX";
VCL_ENUM VENUM(IDENTITY) = "IDENTITY";
VCL_ENUM VENUM(LOWER) = "LOWER";
VCL_ENUM VENUM(UPPER) = "UPPER";
VCL_ENUM VENUM(URL) = "URL";

struct VPFX(blob_blob);
typedef VCL_VOID td_vmod_blob_blob__init(VRT_CTX,
    struct VPFX(blob_blob) **, const char *, VCL_ENUM, VCL_STRANDS);
typedef VCL_VOID td_vmod_blob_blob__fini(struct VPFX(
    blob_blob) **);
typedef VCL_BLOB td_vmod_blob_blob_get(VRT_CTX,
    struct VPFX(blob_blob) *);
typedef VCL_STRING td_vmod_blob_blob_encode(VRT_CTX,
    struct VPFX(blob_blob) *, VCL_ENUM, VCL_ENUM);

typedef VCL_BLOB td_vmod_blob_decode(VRT_CTX, VCL_ENUM, VCL_INT,
    VCL_STRANDS);
typedef VCL_STRING td_vmod_blob_encode(VRT_CTX, VCL_ENUM,
    VCL_ENUM, VCL_BLOB);
typedef VCL_STRING td_vmod_blob_transcode(VRT_CTX, VCL_ENUM,
    VCL_ENUM, VCL_ENUM, VCL_INT, VCL_STRANDS);
typedef VCL_BOOL td_vmod_blob_same(VRT_CTX, VCL_BLOB, VCL_BLOB);
typedef VCL_BOOL td_vmod_blob_equal(VRT_CTX, VCL_BLOB,
    VCL_BLOB);
typedef VCL_INT td_vmod_blob_length(VRT_CTX, VCL_BLOB);
typedef VCL_BLOB td_vmod_blob_sub(VRT_CTX, VCL_BLOB, VCL_BYTES,
    VCL_BYTES);

struct Vmod_vmod_blob_Func {
	td_vmod_blob_decode		*f_decode;
	td_vmod_blob_encode		*f_encode;
	td_vmod_blob_transcode		*f_transcode;
	td_vmod_blob_same		*f_same;
	td_vmod_blob_equal		*f_equal;
	td_vmod_blob_length		*f_length;
	td_vmod_blob_sub		*f_sub;
	td_vmod_blob_blob__init		*f_blob__init;
	td_vmod_blob_blob__fini		*f_blob__fini;
	td_vmod_blob_blob_get		*f_blob_get;
	td_vmod_blob_blob_encode	*f_blob_encode;

	VCL_ENUM			*enum_BASE64;
	VCL_ENUM			*enum_BASE64CF;
	VCL_ENUM			*enum_BASE64URL;
	VCL_ENUM			*enum_BASE64URLNOPAD;
	VCL_ENUM			*enum_DEFAULT;
	VCL_ENUM			*enum_HEX;
	VCL_ENUM			*enum_IDENTITY;
	VCL_ENUM			*enum_LOWER;
	VCL_ENUM			*enum_UPPER;
	VCL_ENUM			*enum_URL;
};

/*lint -esym(754, Vmod_vmod_blob_Func::*) */

static const struct Vmod_vmod_blob_Func Vmod_vmod_blob_Func = {
	.f_decode =			vmod_decode,
	.f_encode =			vmod_encode,
	.f_transcode =			vmod_transcode,
	.f_same =			vmod_same,
	.f_equal =			vmod_equal,
	.f_length =			vmod_length,
	.f_sub =			vmod_sub,
	.f_blob__init =			vmod_blob__init,
	.f_blob__fini =			vmod_blob__fini,
	.f_blob_get =			vmod_blob_get,
	.f_blob_encode =		vmod_blob_encode,


	.enum_BASE64 =			&VENUM(BASE64),
	.enum_BASE64CF =		&VENUM(BASE64CF),
	.enum_BASE64URL =		&VENUM(BASE64URL),
	.enum_BASE64URLNOPAD =		&VENUM(BASE64URLNOPAD),
	.enum_DEFAULT =			&VENUM(DEFAULT),
	.enum_HEX =			&VENUM(HEX),
	.enum_IDENTITY =		&VENUM(IDENTITY),
	.enum_LOWER =			&VENUM(LOWER),
	.enum_UPPER =			&VENUM(UPPER),
	.enum_URL =			&VENUM(URL),
};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"blob\", "
	"    \"Vmod_vmod_blob_Func\", "
	"    \"7323039e744692bee479073a279c3ab2d16d0eb58e61086b7dc2bf49b6e753bd\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_blob_##a\", "
	"    \"#define VENUM(a) enum_vmod_blob_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"struct VPFX(blob_blob);\", "
	"    \"typedef VCL_VOID td_vmod_blob_blob__init(VRT_CTX,\", "
	"    \"    struct VPFX(blob_blob) **, const char *, VCL_ENUM, VCL_STRANDS);\", "
	"    \"typedef VCL_VOID td_vmod_blob_blob__fini(struct VPFX(\", "
	"    \"    blob_blob) **);\", "
	"    \"typedef VCL_BLOB td_vmod_blob_blob_get(VRT_CTX,\", "
	"    \"    struct VPFX(blob_blob) *);\", "
	"    \"typedef VCL_STRING td_vmod_blob_blob_encode(VRT_CTX,\", "
	"    \"    struct VPFX(blob_blob) *, VCL_ENUM, VCL_ENUM);\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_BLOB td_vmod_blob_decode(VRT_CTX, VCL_ENUM, VCL_INT,\", "
	"    \"    VCL_STRANDS);\", "
	"    \"typedef VCL_STRING td_vmod_blob_encode(VRT_CTX, VCL_ENUM,\", "
	"    \"    VCL_ENUM, VCL_BLOB);\", "
	"    \"typedef VCL_STRING td_vmod_blob_transcode(VRT_CTX, VCL_ENUM,\", "
	"    \"    VCL_ENUM, VCL_ENUM, VCL_INT, VCL_STRANDS);\", "
	"    \"typedef VCL_BOOL td_vmod_blob_same(VRT_CTX, VCL_BLOB, VCL_BLOB);\", "
	"    \"typedef VCL_BOOL td_vmod_blob_equal(VRT_CTX, VCL_BLOB,\", "
	"    \"    VCL_BLOB);\", "
	"    \"typedef VCL_INT td_vmod_blob_length(VRT_CTX, VCL_BLOB);\", "
	"    \"typedef VCL_BLOB td_vmod_blob_sub(VRT_CTX, VCL_BLOB, VCL_BYTES,\", "
	"    \"    VCL_BYTES);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_blob_Func {\", "
	"    \"\\ttd_vmod_blob_decode\\t\\t*f_decode;\", "
	"    \"\\ttd_vmod_blob_encode\\t\\t*f_encode;\", "
	"    \"\\ttd_vmod_blob_transcode\\t\\t*f_transcode;\", "
	"    \"\\ttd_vmod_blob_same\\t\\t*f_same;\", "
	"    \"\\ttd_vmod_blob_equal\\t\\t*f_equal;\", "
	"    \"\\ttd_vmod_blob_length\\t\\t*f_length;\", "
	"    \"\\ttd_vmod_blob_sub\\t\\t*f_sub;\", "
	"    \"\\ttd_vmod_blob_blob__init\\t\\t*f_blob__init;\", "
	"    \"\\ttd_vmod_blob_blob__fini\\t\\t*f_blob__fini;\", "
	"    \"\\ttd_vmod_blob_blob_get\\t\\t*f_blob_get;\", "
	"    \"\\ttd_vmod_blob_blob_encode\\t*f_blob_encode;\", "
	"    \"\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_BASE64;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_BASE64CF;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_BASE64URL;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_BASE64URLNOPAD;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_DEFAULT;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_HEX;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_IDENTITY;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_LOWER;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_UPPER;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_URL;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_blob_Func Vmod_vmod_blob_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"decode\", "
	"    [ "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_decode\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        \"decoding\", "
	"        \"IDENTITY\", "
	"        [ "
	"          \"IDENTITY\", "
	"          \"BASE64\", "
	"          \"BASE64URL\", "
	"          \"BASE64URLNOPAD\", "
	"          \"BASE64CF\", "
	"          \"HEX\", "
	"          \"URL\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"INT\", "
	"        \"length\", "
	"        \"0\" "
	"      ], "
	"      [ "
	"        \"STRANDS\", "
	"        \"encoded\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"encode\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_encode\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        \"encoding\", "
	"        \"IDENTITY\", "
	"        [ "
	"          \"IDENTITY\", "
	"          \"BASE64\", "
	"          \"BASE64URL\", "
	"          \"BASE64URLNOPAD\", "
	"          \"BASE64CF\", "
	"          \"HEX\", "
	"          \"URL\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"ENUM\", "
	"        \"case\", "
	"        \"DEFAULT\", "
	"        [ "
	"          \"LOWER\", "
	"          \"UPPER\", "
	"          \"DEFAULT\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"BLOB\", "
	"        \"blob\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"transcode\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_transcode\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        \"decoding\", "
	"        \"IDENTITY\", "
	"        [ "
	"          \"IDENTITY\", "
	"          \"BASE64\", "
	"          \"BASE64URL\", "
	"          \"BASE64URLNOPAD\", "
	"          \"BASE64CF\", "
	"          \"HEX\", "
	"          \"URL\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"ENUM\", "
	"        \"encoding\", "
	"        \"IDENTITY\", "
	"        [ "
	"          \"IDENTITY\", "
	"          \"BASE64\", "
	"          \"BASE64URL\", "
	"          \"BASE64URLNOPAD\", "
	"          \"BASE64CF\", "
	"          \"HEX\", "
	"          \"URL\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"ENUM\", "
	"        \"case\", "
	"        \"DEFAULT\", "
	"        [ "
	"          \"LOWER\", "
	"          \"UPPER\", "
	"          \"DEFAULT\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"INT\", "
	"        \"length\", "
	"        \"0\" "
	"      ], "
	"      [ "
	"        \"STRANDS\", "
	"        \"encoded\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"same\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_same\", "
	"      \"\", "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      [ "
	"        \"BLOB\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"equal\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_equal\", "
	"      \"\", "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      [ "
	"        \"BLOB\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"length\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_length\", "
	"      \"\", "
	"      [ "
	"        \"BLOB\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"sub\", "
	"    [ "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      \"Vmod_vmod_blob_Func.f_sub\", "
	"      \"\", "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      [ "
	"        \"BYTES\", "
	"        \"length\" "
	"      ], "
	"      [ "
	"        \"BYTES\", "
	"        \"offset\", "
	"        \"0\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"blob\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_blob_blob\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_blob_Func.f_blob__init\", "
	"        \"\", "
	"        [ "
	"          \"ENUM\", "
	"          \"decoding\", "
	"          \"IDENTITY\", "
	"          [ "
	"            \"IDENTITY\", "
	"            \"BASE64\", "
	"            \"BASE64URL\", "
	"            \"BASE64URLNOPAD\", "
	"            \"BASE64CF\", "
	"            \"HEX\", "
	"            \"URL\" "
	"          ] "
	"        ], "
	"        [ "
	"          \"STRANDS\", "
	"          \"encoded\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_blob_Func.f_blob__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get\", "
	"      [ "
	"        [ "
	"          \"BLOB\" "
	"        ], "
	"        \"Vmod_vmod_blob_Func.f_blob_get\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"encode\", "
	"      [ "
	"        [ "
	"          \"STRING\" "
	"        ], "
	"        \"Vmod_vmod_blob_Func.f_blob_encode\", "
	"        \"\", "
	"        [ "
	"          \"ENUM\", "
	"          \"encoding\", "
	"          \"IDENTITY\", "
	"          [ "
	"            \"IDENTITY\", "
	"            \"BASE64\", "
	"            \"BASE64URL\", "
	"            \"BASE64URLNOPAD\", "
	"            \"BASE64CF\", "
	"            \"HEX\", "
	"            \"URL\" "
	"          ] "
	"        ], "
	"        [ "
	"          \"ENUM\", "
	"          \"case\", "
	"          \"DEFAULT\", "
	"          [ "
	"            \"LOWER\", "
	"            \"UPPER\", "
	"            \"DEFAULT\" "
	"          ] "
	"        ] "
	"      ] "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_blob_Data) */
/*lint -esym(759, Vmod_blob_Data) */
/*lint -esym(765, Vmod_blob_Data) */

extern const struct vmod_data Vmod_blob_Data;

const struct vmod_data Vmod_blob_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"7323039e744692bee479073a279c3ab2d16d0eb58e61086b7dc2bf49b6e753bd",
	.name =		"blob",
	.func_name =	"Vmod_vmod_blob_Func",
	.func =		&Vmod_vmod_blob_Func,
	.func_len =	sizeof(Vmod_vmod_blob_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
