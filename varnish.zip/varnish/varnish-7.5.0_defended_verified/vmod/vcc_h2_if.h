/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_h2.vcc and run make instead
 */

#ifndef VDEF_H_INCLUDED
#  error "Include vdef.h first"
#endif
#ifndef VRT_H_INCLUDED
#  error "Include vrt.h first"
#endif

#define VPFX(a) vmod_##a
#define VARGS(a) arg_vmod_h2_##a
#define VENUM(a) enum_vmod_h2_##a
//lint -esym(755, VPFX)
//lint -esym(767, VPFX)
//lint -esym(755, VARGS)
//lint -esym(767, VARGS)
//lint -esym(755, VENUM)
//lint -esym(767, VENUM)
//lint -esym(755, VARGS)
//lint -esym(755, VENUM)



VCL_BOOL vmod_is(VRT_CTX);

struct VARGS(rapid_reset) {
	char			valid_threshold;
	VCL_DURATION		threshold;
};
VCL_DURATION vmod_rapid_reset(VRT_CTX,
    struct VARGS(rapid_reset)*);

struct VARGS(rapid_reset_limit) {
	char			valid_number;
	VCL_INT			number;
};
VCL_INT vmod_rapid_reset_limit(VRT_CTX,
    struct VARGS(rapid_reset_limit)*);

struct VARGS(rapid_reset_period) {
	char			valid_duration;
	VCL_DURATION		duration;
};
VCL_DURATION vmod_rapid_reset_period(VRT_CTX,
    struct VARGS(rapid_reset_period)*);
VCL_REAL vmod_rapid_reset_budget(VRT_CTX);
