/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_proxy.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_proxy_if.h"
#include "vmod_abi.h"


typedef VCL_STRING td_vmod_proxy_alpn(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_authority(VRT_CTX);
typedef VCL_BOOL td_vmod_proxy_is_ssl(VRT_CTX);
typedef VCL_BOOL td_vmod_proxy_client_has_cert_sess(VRT_CTX);
typedef VCL_BOOL td_vmod_proxy_client_has_cert_conn(VRT_CTX);
typedef VCL_INT td_vmod_proxy_ssl_verify_result(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_ssl_version(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_client_cert_cn(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_ssl_cipher(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_cert_sign(VRT_CTX);
typedef VCL_STRING td_vmod_proxy_cert_key(VRT_CTX);

struct Vmod_vmod_proxy_Func {
	td_vmod_proxy_alpn		*f_alpn;
	td_vmod_proxy_authority		*f_authority;
	td_vmod_proxy_is_ssl		*f_is_ssl;
	td_vmod_proxy_client_has_cert_sess
					*f_client_has_cert_sess;
	td_vmod_proxy_client_has_cert_conn
					*f_client_has_cert_conn;
	td_vmod_proxy_ssl_verify_result	*f_ssl_verify_result;
	td_vmod_proxy_ssl_version	*f_ssl_version;
	td_vmod_proxy_client_cert_cn	*f_client_cert_cn;
	td_vmod_proxy_ssl_cipher	*f_ssl_cipher;
	td_vmod_proxy_cert_sign		*f_cert_sign;
	td_vmod_proxy_cert_key		*f_cert_key;
};

/*lint -esym(754, Vmod_vmod_proxy_Func::*) */

static const struct Vmod_vmod_proxy_Func Vmod_vmod_proxy_Func = {
	.f_alpn =			vmod_alpn,
	.f_authority =			vmod_authority,
	.f_is_ssl =			vmod_is_ssl,
	.f_client_has_cert_sess =	vmod_client_has_cert_sess,
	.f_client_has_cert_conn =	vmod_client_has_cert_conn,
	.f_ssl_verify_result =		vmod_ssl_verify_result,
	.f_ssl_version =		vmod_ssl_version,
	.f_client_cert_cn =		vmod_client_cert_cn,
	.f_ssl_cipher =			vmod_ssl_cipher,
	.f_cert_sign =			vmod_cert_sign,
	.f_cert_key =			vmod_cert_key,

};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"proxy\", "
	"    \"Vmod_vmod_proxy_Func\", "
	"    \"7e3a20338128569f3a798e8b18eeebe275c78bb5776c815433dc13d7906a1a15\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_proxy_##a\", "
	"    \"#define VENUM(a) enum_vmod_proxy_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_STRING td_vmod_proxy_alpn(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_authority(VRT_CTX);\", "
	"    \"typedef VCL_BOOL td_vmod_proxy_is_ssl(VRT_CTX);\", "
	"    \"typedef VCL_BOOL td_vmod_proxy_client_has_cert_sess(VRT_CTX);\", "
	"    \"typedef VCL_BOOL td_vmod_proxy_client_has_cert_conn(VRT_CTX);\", "
	"    \"typedef VCL_INT td_vmod_proxy_ssl_verify_result(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_ssl_version(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_client_cert_cn(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_ssl_cipher(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_cert_sign(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_proxy_cert_key(VRT_CTX);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_proxy_Func {\", "
	"    \"\\ttd_vmod_proxy_alpn\\t\\t*f_alpn;\", "
	"    \"\\ttd_vmod_proxy_authority\\t\\t*f_authority;\", "
	"    \"\\ttd_vmod_proxy_is_ssl\\t\\t*f_is_ssl;\", "
	"    \"\\ttd_vmod_proxy_client_has_cert_sess\", "
	"    \"\\t\\t\\t\\t\\t*f_client_has_cert_sess;\", "
	"    \"\\ttd_vmod_proxy_client_has_cert_conn\", "
	"    \"\\t\\t\\t\\t\\t*f_client_has_cert_conn;\", "
	"    \"\\ttd_vmod_proxy_ssl_verify_result\\t*f_ssl_verify_result;\", "
	"    \"\\ttd_vmod_proxy_ssl_version\\t*f_ssl_version;\", "
	"    \"\\ttd_vmod_proxy_client_cert_cn\\t*f_client_cert_cn;\", "
	"    \"\\ttd_vmod_proxy_ssl_cipher\\t*f_ssl_cipher;\", "
	"    \"\\ttd_vmod_proxy_cert_sign\\t\\t*f_cert_sign;\", "
	"    \"\\ttd_vmod_proxy_cert_key\\t\\t*f_cert_key;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_proxy_Func Vmod_vmod_proxy_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"alpn\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_alpn\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"authority\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_authority\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"is_ssl\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_is_ssl\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"client_has_cert_sess\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_client_has_cert_sess\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"client_has_cert_conn\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_client_has_cert_conn\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"ssl_verify_result\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_ssl_verify_result\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"ssl_version\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_ssl_version\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"client_cert_cn\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_client_cert_cn\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"ssl_cipher\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_ssl_cipher\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"cert_sign\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_cert_sign\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"cert_key\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_proxy_Func.f_cert_key\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\" "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_proxy_Data) */
/*lint -esym(759, Vmod_proxy_Data) */
/*lint -esym(765, Vmod_proxy_Data) */

extern const struct vmod_data Vmod_proxy_Data;

const struct vmod_data Vmod_proxy_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"7e3a20338128569f3a798e8b18eeebe275c78bb5776c815433dc13d7906a1a15",
	.name =		"proxy",
	.func_name =	"Vmod_vmod_proxy_Func",
	.func =		&Vmod_vmod_proxy_Func,
	.func_len =	sizeof(Vmod_vmod_proxy_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
