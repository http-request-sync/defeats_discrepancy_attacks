/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_unix.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_unix_if.h"
#include "vmod_abi.h"


typedef VCL_STRING td_vmod_unix_user(VRT_CTX);
typedef VCL_STRING td_vmod_unix_group(VRT_CTX);
typedef VCL_INT td_vmod_unix_uid(VRT_CTX);
typedef VCL_INT td_vmod_unix_gid(VRT_CTX);

struct Vmod_vmod_unix_Func {
	td_vmod_unix_user		*f_user;
	td_vmod_unix_group		*f_group;
	td_vmod_unix_uid		*f_uid;
	td_vmod_unix_gid		*f_gid;
};

/*lint -esym(754, Vmod_vmod_unix_Func::*) */

static const struct Vmod_vmod_unix_Func Vmod_vmod_unix_Func = {
	.f_user =			vmod_user,
	.f_group =			vmod_group,
	.f_uid =			vmod_uid,
	.f_gid =			vmod_gid,

};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"unix\", "
	"    \"Vmod_vmod_unix_Func\", "
	"    \"ea43c390b23096a5227e53712abd1ccb525f8c6a25b19905da98f8c70edd0759\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_unix_##a\", "
	"    \"#define VENUM(a) enum_vmod_unix_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_STRING td_vmod_unix_user(VRT_CTX);\", "
	"    \"typedef VCL_STRING td_vmod_unix_group(VRT_CTX);\", "
	"    \"typedef VCL_INT td_vmod_unix_uid(VRT_CTX);\", "
	"    \"typedef VCL_INT td_vmod_unix_gid(VRT_CTX);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_unix_Func {\", "
	"    \"\\ttd_vmod_unix_user\\t\\t*f_user;\", "
	"    \"\\ttd_vmod_unix_group\\t\\t*f_group;\", "
	"    \"\\ttd_vmod_unix_uid\\t\\t*f_uid;\", "
	"    \"\\ttd_vmod_unix_gid\\t\\t*f_gid;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_unix_Func Vmod_vmod_unix_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"user\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_unix_Func.f_user\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\", "
	"      \"backend\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"group\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_unix_Func.f_group\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\", "
	"      \"backend\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"uid\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_unix_Func.f_uid\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\", "
	"      \"backend\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"gid\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_unix_Func.f_gid\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"client\", "
	"      \"backend\" "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_unix_Data) */
/*lint -esym(759, Vmod_unix_Data) */
/*lint -esym(765, Vmod_unix_Data) */

extern const struct vmod_data Vmod_unix_Data;

const struct vmod_data Vmod_unix_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"ea43c390b23096a5227e53712abd1ccb525f8c6a25b19905da98f8c70edd0759",
	.name =		"unix",
	.func_name =	"Vmod_vmod_unix_Func",
	.func =		&Vmod_vmod_unix_Func,
	.func_len =	sizeof(Vmod_vmod_unix_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
