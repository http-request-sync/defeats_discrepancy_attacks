/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_vtc.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_vtc_if.h"
#include "vmod_abi.h"

VCL_ENUM VENUM(b) = "b";
VCL_ENUM VENUM(backend) = "backend";
VCL_ENUM VENUM(c) = "c";
VCL_ENUM VENUM(client) = "client";
VCL_ENUM VENUM(f) = "f";
VCL_ENUM VENUM(r) = "r";
VCL_ENUM VENUM(s) = "s";
VCL_ENUM VENUM(session) = "session";
VCL_ENUM VENUM(thread) = "thread";
VCL_ENUM VENUM(v1) = "v1";
VCL_ENUM VENUM(v2) = "v2";

typedef VCL_VOID td_vmod_vtc_barrier_sync(VRT_CTX, VCL_STRING,
    VCL_DURATION);
typedef VCL_BACKEND td_vmod_vtc_no_backend(VRT_CTX);
typedef VCL_STEVEDORE td_vmod_vtc_no_stevedore(VRT_CTX);
typedef VCL_IP td_vmod_vtc_no_ip(VRT_CTX);
typedef VCL_VOID td_vmod_vtc_panic(VRT_CTX, VCL_STRANDS);
typedef VCL_VOID td_vmod_vtc_sleep(VRT_CTX, VCL_DURATION);
typedef VCL_VOID td_vmod_vtc_workspace_alloc(VRT_CTX, VCL_ENUM,
    VCL_INT);
typedef VCL_BYTES td_vmod_vtc_workspace_reserve(VRT_CTX,
    VCL_ENUM, VCL_INT);
typedef VCL_INT td_vmod_vtc_workspace_free(VRT_CTX, VCL_ENUM);
typedef VCL_VOID td_vmod_vtc_workspace_snapshot(VRT_CTX,
    VCL_ENUM);
typedef VCL_VOID td_vmod_vtc_workspace_reset(VRT_CTX, VCL_ENUM);
typedef VCL_BOOL td_vmod_vtc_workspace_overflowed(VRT_CTX,
    VCL_ENUM);
typedef VCL_VOID td_vmod_vtc_workspace_overflow(VRT_CTX,
    VCL_ENUM);
typedef VCL_BLOB td_vmod_vtc_workspace_dump(VRT_CTX, VCL_ENUM,
    VCL_ENUM, VCL_BYTES, VCL_BYTES);
typedef VCL_INT td_vmod_vtc_typesize(VRT_CTX, VCL_STRING);
typedef VCL_BLOB td_vmod_vtc_proxy_header(VRT_CTX, VCL_ENUM,
    VCL_IP, VCL_IP, VCL_STRING);
typedef VCL_VOID td_vmod_vtc_vsl(VRT_CTX, VCL_INT, VCL_STRING,
    VCL_ENUM, VCL_STRANDS);
typedef VCL_VOID td_vmod_vtc_vsl_replay(VRT_CTX, VCL_STRANDS);

struct Vmod_vmod_vtc_Func {
	td_vmod_vtc_barrier_sync	*f_barrier_sync;
	td_vmod_vtc_no_backend		*f_no_backend;
	td_vmod_vtc_no_stevedore	*f_no_stevedore;
	td_vmod_vtc_no_ip		*f_no_ip;
	td_vmod_vtc_panic		*f_panic;
	td_vmod_vtc_sleep		*f_sleep;
	td_vmod_vtc_workspace_alloc	*f_workspace_alloc;
	td_vmod_vtc_workspace_reserve	*f_workspace_reserve;
	td_vmod_vtc_workspace_free	*f_workspace_free;
	td_vmod_vtc_workspace_snapshot	*f_workspace_snapshot;
	td_vmod_vtc_workspace_reset	*f_workspace_reset;
	td_vmod_vtc_workspace_overflowed	*f_workspace_overflowed;
	td_vmod_vtc_workspace_overflow	*f_workspace_overflow;
	td_vmod_vtc_workspace_dump	*f_workspace_dump;
	td_vmod_vtc_typesize		*f_typesize;
	td_vmod_vtc_proxy_header	*f_proxy_header;
	td_vmod_vtc_vsl			*f_vsl;
	td_vmod_vtc_vsl_replay		*f_vsl_replay;
	VCL_ENUM			*enum_b;
	VCL_ENUM			*enum_backend;
	VCL_ENUM			*enum_c;
	VCL_ENUM			*enum_client;
	VCL_ENUM			*enum_f;
	VCL_ENUM			*enum_r;
	VCL_ENUM			*enum_s;
	VCL_ENUM			*enum_session;
	VCL_ENUM			*enum_thread;
	VCL_ENUM			*enum_v1;
	VCL_ENUM			*enum_v2;
};

/*lint -esym(754, Vmod_vmod_vtc_Func::*) */

static const struct Vmod_vmod_vtc_Func Vmod_vmod_vtc_Func = {
	.f_barrier_sync =		vmod_barrier_sync,
	.f_no_backend =			vmod_no_backend,
	.f_no_stevedore =		vmod_no_stevedore,
	.f_no_ip =			vmod_no_ip,
	.f_panic =			vmod_panic,
	.f_sleep =			vmod_sleep,
	.f_workspace_alloc =		vmod_workspace_alloc,
	.f_workspace_reserve =		vmod_workspace_reserve,
	.f_workspace_free =		vmod_workspace_free,
	.f_workspace_snapshot =		vmod_workspace_snapshot,
	.f_workspace_reset =		vmod_workspace_reset,
	.f_workspace_overflowed =	vmod_workspace_overflowed,
	.f_workspace_overflow =		vmod_workspace_overflow,
	.f_workspace_dump =		vmod_workspace_dump,
	.f_typesize =			vmod_typesize,
	.f_proxy_header =		vmod_proxy_header,
	.f_vsl =			vmod_vsl,
	.f_vsl_replay =			vmod_vsl_replay,

	.enum_b =			&VENUM(b),
	.enum_backend =			&VENUM(backend),
	.enum_c =			&VENUM(c),
	.enum_client =			&VENUM(client),
	.enum_f =			&VENUM(f),
	.enum_r =			&VENUM(r),
	.enum_s =			&VENUM(s),
	.enum_session =			&VENUM(session),
	.enum_thread =			&VENUM(thread),
	.enum_v1 =			&VENUM(v1),
	.enum_v2 =			&VENUM(v2),
};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"vtc\", "
	"    \"Vmod_vmod_vtc_Func\", "
	"    \"bbf93fef4737488f92b840d721093213f080b238eb6a638d4d9b313bcb1945b4\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_vtc_##a\", "
	"    \"#define VENUM(a) enum_vmod_vtc_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_VOID td_vmod_vtc_barrier_sync(VRT_CTX, VCL_STRING,\", "
	"    \"    VCL_DURATION);\", "
	"    \"typedef VCL_BACKEND td_vmod_vtc_no_backend(VRT_CTX);\", "
	"    \"typedef VCL_STEVEDORE td_vmod_vtc_no_stevedore(VRT_CTX);\", "
	"    \"typedef VCL_IP td_vmod_vtc_no_ip(VRT_CTX);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_panic(VRT_CTX, VCL_STRANDS);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_sleep(VRT_CTX, VCL_DURATION);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_workspace_alloc(VRT_CTX, VCL_ENUM,\", "
	"    \"    VCL_INT);\", "
	"    \"typedef VCL_BYTES td_vmod_vtc_workspace_reserve(VRT_CTX,\", "
	"    \"    VCL_ENUM, VCL_INT);\", "
	"    \"typedef VCL_INT td_vmod_vtc_workspace_free(VRT_CTX, VCL_ENUM);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_workspace_snapshot(VRT_CTX,\", "
	"    \"    VCL_ENUM);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_workspace_reset(VRT_CTX, VCL_ENUM);\", "
	"    \"typedef VCL_BOOL td_vmod_vtc_workspace_overflowed(VRT_CTX,\", "
	"    \"    VCL_ENUM);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_workspace_overflow(VRT_CTX,\", "
	"    \"    VCL_ENUM);\", "
	"    \"typedef VCL_BLOB td_vmod_vtc_workspace_dump(VRT_CTX, VCL_ENUM,\", "
	"    \"    VCL_ENUM, VCL_BYTES, VCL_BYTES);\", "
	"    \"typedef VCL_INT td_vmod_vtc_typesize(VRT_CTX, VCL_STRING);\", "
	"    \"typedef VCL_BLOB td_vmod_vtc_proxy_header(VRT_CTX, VCL_ENUM,\", "
	"    \"    VCL_IP, VCL_IP, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_vsl(VRT_CTX, VCL_INT, VCL_STRING,\", "
	"    \"    VCL_ENUM, VCL_STRANDS);\", "
	"    \"typedef VCL_VOID td_vmod_vtc_vsl_replay(VRT_CTX, VCL_STRANDS);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_vtc_Func {\", "
	"    \"\\ttd_vmod_vtc_barrier_sync\\t*f_barrier_sync;\", "
	"    \"\\ttd_vmod_vtc_no_backend\\t\\t*f_no_backend;\", "
	"    \"\\ttd_vmod_vtc_no_stevedore\\t*f_no_stevedore;\", "
	"    \"\\ttd_vmod_vtc_no_ip\\t\\t*f_no_ip;\", "
	"    \"\\ttd_vmod_vtc_panic\\t\\t*f_panic;\", "
	"    \"\\ttd_vmod_vtc_sleep\\t\\t*f_sleep;\", "
	"    \"\\ttd_vmod_vtc_workspace_alloc\\t*f_workspace_alloc;\", "
	"    \"\\ttd_vmod_vtc_workspace_reserve\\t*f_workspace_reserve;\", "
	"    \"\\ttd_vmod_vtc_workspace_free\\t*f_workspace_free;\", "
	"    \"\\ttd_vmod_vtc_workspace_snapshot\\t*f_workspace_snapshot;\", "
	"    \"\\ttd_vmod_vtc_workspace_reset\\t*f_workspace_reset;\", "
	"    \"\\ttd_vmod_vtc_workspace_overflowed\\t*f_workspace_overflowed;\", "
	"    \"\\ttd_vmod_vtc_workspace_overflow\\t*f_workspace_overflow;\", "
	"    \"\\ttd_vmod_vtc_workspace_dump\\t*f_workspace_dump;\", "
	"    \"\\ttd_vmod_vtc_typesize\\t\\t*f_typesize;\", "
	"    \"\\ttd_vmod_vtc_proxy_header\\t*f_proxy_header;\", "
	"    \"\\ttd_vmod_vtc_vsl\\t\\t\\t*f_vsl;\", "
	"    \"\\ttd_vmod_vtc_vsl_replay\\t\\t*f_vsl_replay;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_b;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_backend;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_c;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_client;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_f;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_r;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_s;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_session;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_thread;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_v1;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_v2;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_vtc_Func Vmod_vmod_vtc_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"barrier_sync\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_barrier_sync\", "
	"      \"\", "
	"      [ "
	"        \"STRING\", "
	"        \"addr\" "
	"      ], "
	"      [ "
	"        \"DURATION\", "
	"        \"timeout\", "
	"        \"0\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"no_backend\", "
	"    [ "
	"      [ "
	"        \"BACKEND\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_no_backend\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"no_stevedore\", "
	"    [ "
	"      [ "
	"        \"STEVEDORE\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_no_stevedore\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"no_ip\", "
	"    [ "
	"      [ "
	"        \"IP\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_no_ip\", "
	"      \"\" "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"panic\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_panic\", "
	"      \"\", "
	"      [ "
	"        \"STRANDS\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"sleep\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_sleep\", "
	"      \"\", "
	"      [ "
	"        \"DURATION\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_alloc\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_alloc\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"INT\", "
	"        \"size\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_reserve\", "
	"    [ "
	"      [ "
	"        \"BYTES\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_reserve\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"INT\", "
	"        \"size\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_free\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_free\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_snapshot\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_snapshot\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_reset\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_reset\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_overflowed\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_overflowed\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_overflow\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_overflow\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"workspace_dump\", "
	"    [ "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_workspace_dump\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"client\", "
	"          \"backend\", "
	"          \"session\", "
	"          \"thread\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"ENUM\", "
	"        null, "
	"        null, "
	"        [ "
	"          \"s\", "
	"          \"f\", "
	"          \"r\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"BYTES\", "
	"        \"off\", "
	"        \"0\" "
	"      ], "
	"      [ "
	"        \"BYTES\", "
	"        \"len\", "
	"        \"64\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"typesize\", "
	"    [ "
	"      [ "
	"        \"INT\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_typesize\", "
	"      \"\", "
	"      [ "
	"        \"STRING\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"proxy_header\", "
	"    [ "
	"      [ "
	"        \"BLOB\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_proxy_header\", "
	"      \"\", "
	"      [ "
	"        \"ENUM\", "
	"        \"version\", "
	"        null, "
	"        [ "
	"          \"v1\", "
	"          \"v2\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"IP\", "
	"        \"client\" "
	"      ], "
	"      [ "
	"        \"IP\", "
	"        \"server\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"authority\", "
	"        \"0\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"vsl\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_vsl\", "
	"      \"\", "
	"      [ "
	"        \"INT\", "
	"        \"vxid\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"tag\" "
	"      ], "
	"      [ "
	"        \"ENUM\", "
	"        \"side\", "
	"        null, "
	"        [ "
	"          \"c\", "
	"          \"b\" "
	"        ] "
	"      ], "
	"      [ "
	"        \"STRANDS\", "
	"        \"s\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"vsl_replay\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_vtc_Func.f_vsl_replay\", "
	"      \"\", "
	"      [ "
	"        \"STRANDS\", "
	"        \"s\" "
	"      ] "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_vtc_Data) */
/*lint -esym(759, Vmod_vtc_Data) */
/*lint -esym(765, Vmod_vtc_Data) */

extern const struct vmod_data Vmod_vtc_Data;

const struct vmod_data Vmod_vtc_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"bbf93fef4737488f92b840d721093213f080b238eb6a638d4d9b313bcb1945b4",
	.name =		"vtc",
	.func_name =	"Vmod_vmod_vtc_Func",
	.func =		&Vmod_vmod_vtc_Func,
	.func_len =	sizeof(Vmod_vmod_vtc_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
