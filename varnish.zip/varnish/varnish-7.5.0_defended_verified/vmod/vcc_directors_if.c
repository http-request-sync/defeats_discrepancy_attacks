/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_directors.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_directors_if.h"
#include "vmod_abi.h"

VCL_ENUM VENUM(ALL) = "ALL";
VCL_ENUM VENUM(BLOB) = "BLOB";
VCL_ENUM VENUM(CHOSEN) = "CHOSEN";
VCL_ENUM VENUM(HASH) = "HASH";
VCL_ENUM VENUM(IGNORE) = "IGNORE";
VCL_ENUM VENUM(KEY) = "KEY";
VCL_ENUM VENUM(LAZY) = "LAZY";
VCL_ENUM VENUM(NOW) = "NOW";
VCL_ENUM VENUM(URL) = "URL";

struct VPFX(directors_round_robin);
typedef VCL_VOID td_vmod_directors_round_robin__init(VRT_CTX,
    struct VPFX(directors_round_robin) **, const char *);
typedef VCL_VOID td_vmod_directors_round_robin__fini(
    struct VPFX(directors_round_robin) **);
typedef VCL_VOID td_vmod_directors_round_robin_add_backend(
    VRT_CTX, struct VPFX(directors_round_robin) *, VCL_BACKEND);
typedef VCL_VOID td_vmod_directors_round_robin_remove_backend(
    VRT_CTX, struct VPFX(directors_round_robin) *, VCL_BACKEND);
typedef VCL_BACKEND td_vmod_directors_round_robin_backend(
    VRT_CTX, struct VPFX(directors_round_robin) *);

struct VPFX(directors_fallback);
typedef VCL_VOID td_vmod_directors_fallback__init(VRT_CTX,
    struct VPFX(directors_fallback) **, const char *, VCL_BOOL);
typedef VCL_VOID td_vmod_directors_fallback__fini(struct VPFX(
    directors_fallback) **);
typedef VCL_VOID td_vmod_directors_fallback_add_backend(VRT_CTX,
    struct VPFX(directors_fallback) *, VCL_BACKEND);
typedef VCL_VOID td_vmod_directors_fallback_remove_backend(
    VRT_CTX, struct VPFX(directors_fallback) *, VCL_BACKEND);
typedef VCL_BACKEND td_vmod_directors_fallback_backend(VRT_CTX,
    struct VPFX(directors_fallback) *);

struct VPFX(directors_random);
typedef VCL_VOID td_vmod_directors_random__init(VRT_CTX,
    struct VPFX(directors_random) **, const char *);
typedef VCL_VOID td_vmod_directors_random__fini(struct VPFX(
    directors_random) **);
typedef VCL_VOID td_vmod_directors_random_add_backend(VRT_CTX,
    struct VPFX(directors_random) *, VCL_BACKEND, VCL_REAL);
typedef VCL_VOID td_vmod_directors_random_remove_backend(
    VRT_CTX, struct VPFX(directors_random) *, VCL_BACKEND);
typedef VCL_BACKEND td_vmod_directors_random_backend(VRT_CTX,
    struct VPFX(directors_random) *);

struct VPFX(directors_hash);
typedef VCL_VOID td_vmod_directors_hash__init(VRT_CTX,
    struct VPFX(directors_hash) **, const char *);
typedef VCL_VOID td_vmod_directors_hash__fini(struct VPFX(
    directors_hash) **);
typedef VCL_VOID td_vmod_directors_hash_add_backend(VRT_CTX,
    struct VPFX(directors_hash) *, VCL_BACKEND, VCL_REAL);
typedef VCL_VOID td_vmod_directors_hash_remove_backend(VRT_CTX,
    struct VPFX(directors_hash) *, VCL_BACKEND);
typedef VCL_BACKEND td_vmod_directors_hash_backend(VRT_CTX,
    struct VPFX(directors_hash) *, VCL_STRANDS);

struct VPFX(directors_shard);
typedef VCL_VOID td_vmod_directors_shard__init(VRT_CTX,
    struct VPFX(directors_shard) **, const char *);
typedef VCL_VOID td_vmod_directors_shard__fini(struct VPFX(
    directors_shard) **);
typedef VCL_VOID td_vmod_directors_shard_set_warmup(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_REAL);
typedef VCL_VOID td_vmod_directors_shard_set_rampup(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_DURATION);
typedef VCL_VOID td_vmod_directors_shard_associate(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_BLOB);
typedef VCL_BOOL td_vmod_directors_shard_add_backend(VRT_CTX,
    struct VPFX(directors_shard) *,
    struct VARGS(shard_add_backend)*);
typedef VCL_BOOL td_vmod_directors_shard_remove_backend(VRT_CTX,
    struct VPFX(directors_shard) *,
    struct VARGS(shard_remove_backend)*);
typedef VCL_BOOL td_vmod_directors_shard_clear(VRT_CTX,
    struct VPFX(directors_shard) *);
typedef VCL_BOOL td_vmod_directors_shard_reconfigure(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_INT);
typedef VCL_INT td_vmod_directors_shard_key(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_STRANDS);
typedef VCL_BACKEND td_vmod_directors_shard_backend(VRT_CTX,
    struct VPFX(directors_shard) *, struct VARGS(shard_backend)*);
typedef VCL_VOID td_vmod_directors_shard_debug(VRT_CTX,
    struct VPFX(directors_shard) *, VCL_INT);

struct VPFX(directors_shard_param);
typedef VCL_VOID td_vmod_directors_shard_param__init(VRT_CTX,
    struct VPFX(directors_shard_param) **, const char *);
typedef VCL_VOID td_vmod_directors_shard_param__fini(
    struct VPFX(directors_shard_param) **);
typedef VCL_VOID td_vmod_directors_shard_param_clear(VRT_CTX,
    struct VPFX(directors_shard_param) *);
typedef VCL_VOID td_vmod_directors_shard_param_set(VRT_CTX,
    struct VPFX(directors_shard_param) *,
    struct VARGS(shard_param_set)*);
typedef VCL_STRING td_vmod_directors_shard_param_get_by(VRT_CTX,
    struct VPFX(directors_shard_param) *);
typedef VCL_INT td_vmod_directors_shard_param_get_key(VRT_CTX,
    struct VPFX(directors_shard_param) *);
typedef VCL_INT td_vmod_directors_shard_param_get_alt(VRT_CTX,
    struct VPFX(directors_shard_param) *);
typedef VCL_REAL td_vmod_directors_shard_param_get_warmup(
    VRT_CTX, struct VPFX(directors_shard_param) *);
typedef VCL_BOOL td_vmod_directors_shard_param_get_rampup(
    VRT_CTX, struct VPFX(directors_shard_param) *);
typedef VCL_STRING td_vmod_directors_shard_param_get_healthy(
    VRT_CTX, struct VPFX(directors_shard_param) *);
typedef VCL_BLOB td_vmod_directors_shard_param_use(VRT_CTX,
    struct VPFX(directors_shard_param) *);

typedef VCL_BACKEND td_vmod_directors_lookup(VRT_CTX,
    VCL_STRING);

struct Vmod_vmod_directors_Func {
	td_vmod_directors_round_robin__init
					*f_round_robin__init;
	td_vmod_directors_round_robin__fini
					*f_round_robin__fini;
	td_vmod_directors_round_robin_add_backend
					*f_round_robin_add_backend;
	td_vmod_directors_round_robin_remove_backend
					*f_round_robin_remove_backend;
	td_vmod_directors_round_robin_backend
					*f_round_robin_backend;

	td_vmod_directors_fallback__init	*f_fallback__init;
	td_vmod_directors_fallback__fini	*f_fallback__fini;
	td_vmod_directors_fallback_add_backend
					*f_fallback_add_backend;
	td_vmod_directors_fallback_remove_backend
					*f_fallback_remove_backend;
	td_vmod_directors_fallback_backend
					*f_fallback_backend;

	td_vmod_directors_random__init	*f_random__init;
	td_vmod_directors_random__fini	*f_random__fini;
	td_vmod_directors_random_add_backend
					*f_random_add_backend;
	td_vmod_directors_random_remove_backend
					*f_random_remove_backend;
	td_vmod_directors_random_backend	*f_random_backend;

	td_vmod_directors_hash__init	*f_hash__init;
	td_vmod_directors_hash__fini	*f_hash__fini;
	td_vmod_directors_hash_add_backend
					*f_hash_add_backend;
	td_vmod_directors_hash_remove_backend
					*f_hash_remove_backend;
	td_vmod_directors_hash_backend	*f_hash_backend;

	td_vmod_directors_shard__init	*f_shard__init;
	td_vmod_directors_shard__fini	*f_shard__fini;
	td_vmod_directors_shard_set_warmup
					*f_shard_set_warmup;
	td_vmod_directors_shard_set_rampup
					*f_shard_set_rampup;
	td_vmod_directors_shard_associate
					*f_shard_associate;
	td_vmod_directors_shard_add_backend
					*f_shard_add_backend;
	td_vmod_directors_shard_remove_backend
					*f_shard_remove_backend;
	td_vmod_directors_shard_clear	*f_shard_clear;
	td_vmod_directors_shard_reconfigure
					*f_shard_reconfigure;
	td_vmod_directors_shard_key	*f_shard_key;
	td_vmod_directors_shard_backend	*f_shard_backend;
	td_vmod_directors_shard_debug	*f_shard_debug;

	td_vmod_directors_shard_param__init
					*f_shard_param__init;
	td_vmod_directors_shard_param__fini
					*f_shard_param__fini;
	td_vmod_directors_shard_param_clear
					*f_shard_param_clear;
	td_vmod_directors_shard_param_set
					*f_shard_param_set;
	td_vmod_directors_shard_param_get_by
					*f_shard_param_get_by;
	td_vmod_directors_shard_param_get_key
					*f_shard_param_get_key;
	td_vmod_directors_shard_param_get_alt
					*f_shard_param_get_alt;
	td_vmod_directors_shard_param_get_warmup
					*f_shard_param_get_warmup;
	td_vmod_directors_shard_param_get_rampup
					*f_shard_param_get_rampup;
	td_vmod_directors_shard_param_get_healthy
					*f_shard_param_get_healthy;
	td_vmod_directors_shard_param_use
					*f_shard_param_use;

	td_vmod_directors_lookup	*f_lookup;
	VCL_ENUM			*enum_ALL;
	VCL_ENUM			*enum_BLOB;
	VCL_ENUM			*enum_CHOSEN;
	VCL_ENUM			*enum_HASH;
	VCL_ENUM			*enum_IGNORE;
	VCL_ENUM			*enum_KEY;
	VCL_ENUM			*enum_LAZY;
	VCL_ENUM			*enum_NOW;
	VCL_ENUM			*enum_URL;
};

/*lint -esym(754, Vmod_vmod_directors_Func::*) */

static const struct Vmod_vmod_directors_Func Vmod_vmod_directors_Func = {
	.f_round_robin__init =		vmod_round_robin__init,
	.f_round_robin__fini =		vmod_round_robin__fini,
	.f_round_robin_add_backend =	vmod_round_robin_add_backend,
	.f_round_robin_remove_backend =	vmod_round_robin_remove_backend,
	.f_round_robin_backend =	vmod_round_robin_backend,

	.f_fallback__init =		vmod_fallback__init,
	.f_fallback__fini =		vmod_fallback__fini,
	.f_fallback_add_backend =	vmod_fallback_add_backend,
	.f_fallback_remove_backend =	vmod_fallback_remove_backend,
	.f_fallback_backend =		vmod_fallback_backend,

	.f_random__init =		vmod_random__init,
	.f_random__fini =		vmod_random__fini,
	.f_random_add_backend =		vmod_random_add_backend,
	.f_random_remove_backend =	vmod_random_remove_backend,
	.f_random_backend =		vmod_random_backend,

	.f_hash__init =			vmod_hash__init,
	.f_hash__fini =			vmod_hash__fini,
	.f_hash_add_backend =		vmod_hash_add_backend,
	.f_hash_remove_backend =	vmod_hash_remove_backend,
	.f_hash_backend =		vmod_hash_backend,

	.f_shard__init =		vmod_shard__init,
	.f_shard__fini =		vmod_shard__fini,
	.f_shard_set_warmup =		vmod_shard_set_warmup,
	.f_shard_set_rampup =		vmod_shard_set_rampup,
	.f_shard_associate =		vmod_shard_associate,
	.f_shard_add_backend =		vmod_shard_add_backend,
	.f_shard_remove_backend =	vmod_shard_remove_backend,
	.f_shard_clear =		vmod_shard_clear,
	.f_shard_reconfigure =		vmod_shard_reconfigure,
	.f_shard_key =			vmod_shard_key,
	.f_shard_backend =		vmod_shard_backend,
	.f_shard_debug =		vmod_shard_debug,

	.f_shard_param__init =		vmod_shard_param__init,
	.f_shard_param__fini =		vmod_shard_param__fini,
	.f_shard_param_clear =		vmod_shard_param_clear,
	.f_shard_param_set =		vmod_shard_param_set,
	.f_shard_param_get_by =		vmod_shard_param_get_by,
	.f_shard_param_get_key =	vmod_shard_param_get_key,
	.f_shard_param_get_alt =	vmod_shard_param_get_alt,
	.f_shard_param_get_warmup =	vmod_shard_param_get_warmup,
	.f_shard_param_get_rampup =	vmod_shard_param_get_rampup,
	.f_shard_param_get_healthy =	vmod_shard_param_get_healthy,
	.f_shard_param_use =		vmod_shard_param_use,

	.f_lookup =			vmod_lookup,

	.enum_ALL =			&VENUM(ALL),
	.enum_BLOB =			&VENUM(BLOB),
	.enum_CHOSEN =			&VENUM(CHOSEN),
	.enum_HASH =			&VENUM(HASH),
	.enum_IGNORE =			&VENUM(IGNORE),
	.enum_KEY =			&VENUM(KEY),
	.enum_LAZY =			&VENUM(LAZY),
	.enum_NOW =			&VENUM(NOW),
	.enum_URL =			&VENUM(URL),
};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"directors\", "
	"    \"Vmod_vmod_directors_Func\", "
	"    \"edab1c2b46260ba7857d12e0b786d29b78460cd930959505a67272486eac4683\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_directors_##a\", "
	"    \"#define VENUM(a) enum_vmod_directors_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"struct VPFX(directors_round_robin);\", "
	"    \"typedef VCL_VOID td_vmod_directors_round_robin__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_round_robin) **, const char *);\", "
	"    \"typedef VCL_VOID td_vmod_directors_round_robin__fini(\", "
	"    \"    struct VPFX(directors_round_robin) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_round_robin_add_backend(\", "
	"    \"    VRT_CTX, struct VPFX(directors_round_robin) *, VCL_BACKEND);\", "
	"    \"typedef VCL_VOID td_vmod_directors_round_robin_remove_backend(\", "
	"    \"    VRT_CTX, struct VPFX(directors_round_robin) *, VCL_BACKEND);\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_round_robin_backend(\", "
	"    \"    VRT_CTX, struct VPFX(directors_round_robin) *);\", "
	"    \"\", "
	"    \"struct VPFX(directors_fallback);\", "
	"    \"typedef VCL_VOID td_vmod_directors_fallback__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_fallback) **, const char *, VCL_BOOL);\", "
	"    \"typedef VCL_VOID td_vmod_directors_fallback__fini(struct VPFX(\", "
	"    \"    directors_fallback) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_fallback_add_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_fallback) *, VCL_BACKEND);\", "
	"    \"typedef VCL_VOID td_vmod_directors_fallback_remove_backend(\", "
	"    \"    VRT_CTX, struct VPFX(directors_fallback) *, VCL_BACKEND);\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_fallback_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_fallback) *);\", "
	"    \"\", "
	"    \"struct VPFX(directors_random);\", "
	"    \"typedef VCL_VOID td_vmod_directors_random__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_random) **, const char *);\", "
	"    \"typedef VCL_VOID td_vmod_directors_random__fini(struct VPFX(\", "
	"    \"    directors_random) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_random_add_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_random) *, VCL_BACKEND, VCL_REAL);\", "
	"    \"typedef VCL_VOID td_vmod_directors_random_remove_backend(\", "
	"    \"    VRT_CTX, struct VPFX(directors_random) *, VCL_BACKEND);\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_random_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_random) *);\", "
	"    \"\", "
	"    \"struct VPFX(directors_hash);\", "
	"    \"typedef VCL_VOID td_vmod_directors_hash__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_hash) **, const char *);\", "
	"    \"typedef VCL_VOID td_vmod_directors_hash__fini(struct VPFX(\", "
	"    \"    directors_hash) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_hash_add_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_hash) *, VCL_BACKEND, VCL_REAL);\", "
	"    \"typedef VCL_VOID td_vmod_directors_hash_remove_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_hash) *, VCL_BACKEND);\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_hash_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_hash) *, VCL_STRANDS);\", "
	"    \"\", "
	"    \"struct VPFX(directors_shard);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) **, const char *);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard__fini(struct VPFX(\", "
	"    \"    directors_shard) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_set_warmup(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_REAL);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_set_rampup(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_DURATION);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_associate(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_BLOB);\", "
	"    \"\", "
	"    \"struct VARGS(shard_add_backend) {\", "
	"    \"\\tchar\\t\\t\\tvalid_ident;\", "
	"    \"\\tchar\\t\\t\\tvalid_rampup;\", "
	"    \"\\tchar\\t\\t\\tvalid_weight;\", "
	"    \"\\tVCL_BACKEND\\t\\tbackend;\", "
	"    \"\\tVCL_STRING\\t\\tident;\", "
	"    \"\\tVCL_DURATION\\t\\trampup;\", "
	"    \"\\tVCL_REAL\\t\\tweight;\", "
	"    \"};\", "
	"    \"typedef VCL_BOOL td_vmod_directors_shard_add_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *,\", "
	"    \"    struct VARGS(shard_add_backend)*);\", "
	"    \"\", "
	"    \"struct VARGS(shard_remove_backend) {\", "
	"    \"\\tchar\\t\\t\\tvalid_backend;\", "
	"    \"\\tchar\\t\\t\\tvalid_ident;\", "
	"    \"\\tVCL_BACKEND\\t\\tbackend;\", "
	"    \"\\tVCL_STRING\\t\\tident;\", "
	"    \"};\", "
	"    \"typedef VCL_BOOL td_vmod_directors_shard_remove_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *,\", "
	"    \"    struct VARGS(shard_remove_backend)*);\", "
	"    \"typedef VCL_BOOL td_vmod_directors_shard_clear(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *);\", "
	"    \"typedef VCL_BOOL td_vmod_directors_shard_reconfigure(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_INT);\", "
	"    \"typedef VCL_INT td_vmod_directors_shard_key(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_STRANDS);\", "
	"    \"\", "
	"    \"struct VARGS(shard_backend) {\", "
	"    \"\\tchar\\t\\t\\tvalid_by;\", "
	"    \"\\tchar\\t\\t\\tvalid_key;\", "
	"    \"\\tchar\\t\\t\\tvalid_key_blob;\", "
	"    \"\\tchar\\t\\t\\tvalid_alt;\", "
	"    \"\\tchar\\t\\t\\tvalid_warmup;\", "
	"    \"\\tchar\\t\\t\\tvalid_rampup;\", "
	"    \"\\tchar\\t\\t\\tvalid_healthy;\", "
	"    \"\\tchar\\t\\t\\tvalid_param;\", "
	"    \"\\tchar\\t\\t\\tvalid_resolve;\", "
	"    \"\\tVCL_ENUM\\t\\tby;\", "
	"    \"\\tVCL_INT\\t\\t\\tkey;\", "
	"    \"\\tVCL_BLOB\\t\\tkey_blob;\", "
	"    \"\\tVCL_INT\\t\\t\\talt;\", "
	"    \"\\tVCL_REAL\\t\\twarmup;\", "
	"    \"\\tVCL_BOOL\\t\\trampup;\", "
	"    \"\\tVCL_ENUM\\t\\thealthy;\", "
	"    \"\\tVCL_BLOB\\t\\tparam;\", "
	"    \"\\tVCL_ENUM\\t\\tresolve;\", "
	"    \"};\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_shard_backend(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, struct VARGS(shard_backend)*);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_debug(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard) *, VCL_INT);\", "
	"    \"\", "
	"    \"struct VPFX(directors_shard_param);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_param__init(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) **, const char *);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_param__fini(\", "
	"    \"    struct VPFX(directors_shard_param) **);\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_param_clear(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *);\", "
	"    \"\", "
	"    \"struct VARGS(shard_param_set) {\", "
	"    \"\\tchar\\t\\t\\tvalid_by;\", "
	"    \"\\tchar\\t\\t\\tvalid_key;\", "
	"    \"\\tchar\\t\\t\\tvalid_key_blob;\", "
	"    \"\\tchar\\t\\t\\tvalid_alt;\", "
	"    \"\\tchar\\t\\t\\tvalid_warmup;\", "
	"    \"\\tchar\\t\\t\\tvalid_rampup;\", "
	"    \"\\tchar\\t\\t\\tvalid_healthy;\", "
	"    \"\\tVCL_ENUM\\t\\tby;\", "
	"    \"\\tVCL_INT\\t\\t\\tkey;\", "
	"    \"\\tVCL_BLOB\\t\\tkey_blob;\", "
	"    \"\\tVCL_INT\\t\\t\\talt;\", "
	"    \"\\tVCL_REAL\\t\\twarmup;\", "
	"    \"\\tVCL_BOOL\\t\\trampup;\", "
	"    \"\\tVCL_ENUM\\t\\thealthy;\", "
	"    \"};\", "
	"    \"typedef VCL_VOID td_vmod_directors_shard_param_set(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *,\", "
	"    \"    struct VARGS(shard_param_set)*);\", "
	"    \"typedef VCL_STRING td_vmod_directors_shard_param_get_by(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_INT td_vmod_directors_shard_param_get_key(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_INT td_vmod_directors_shard_param_get_alt(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_REAL td_vmod_directors_shard_param_get_warmup(\", "
	"    \"    VRT_CTX, struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_BOOL td_vmod_directors_shard_param_get_rampup(\", "
	"    \"    VRT_CTX, struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_STRING td_vmod_directors_shard_param_get_healthy(\", "
	"    \"    VRT_CTX, struct VPFX(directors_shard_param) *);\", "
	"    \"typedef VCL_BLOB td_vmod_directors_shard_param_use(VRT_CTX,\", "
	"    \"    struct VPFX(directors_shard_param) *);\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_BACKEND td_vmod_directors_lookup(VRT_CTX,\", "
	"    \"    VCL_STRING);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_directors_Func {\", "
	"    \"\\ttd_vmod_directors_round_robin__init\", "
	"    \"\\t\\t\\t\\t\\t*f_round_robin__init;\", "
	"    \"\\ttd_vmod_directors_round_robin__fini\", "
	"    \"\\t\\t\\t\\t\\t*f_round_robin__fini;\", "
	"    \"\\ttd_vmod_directors_round_robin_add_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_round_robin_add_backend;\", "
	"    \"\\ttd_vmod_directors_round_robin_remove_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_round_robin_remove_backend;\", "
	"    \"\\ttd_vmod_directors_round_robin_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_round_robin_backend;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_fallback__init\\t*f_fallback__init;\", "
	"    \"\\ttd_vmod_directors_fallback__fini\\t*f_fallback__fini;\", "
	"    \"\\ttd_vmod_directors_fallback_add_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_fallback_add_backend;\", "
	"    \"\\ttd_vmod_directors_fallback_remove_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_fallback_remove_backend;\", "
	"    \"\\ttd_vmod_directors_fallback_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_fallback_backend;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_random__init\\t*f_random__init;\", "
	"    \"\\ttd_vmod_directors_random__fini\\t*f_random__fini;\", "
	"    \"\\ttd_vmod_directors_random_add_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_random_add_backend;\", "
	"    \"\\ttd_vmod_directors_random_remove_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_random_remove_backend;\", "
	"    \"\\ttd_vmod_directors_random_backend\\t*f_random_backend;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_hash__init\\t*f_hash__init;\", "
	"    \"\\ttd_vmod_directors_hash__fini\\t*f_hash__fini;\", "
	"    \"\\ttd_vmod_directors_hash_add_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_hash_add_backend;\", "
	"    \"\\ttd_vmod_directors_hash_remove_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_hash_remove_backend;\", "
	"    \"\\ttd_vmod_directors_hash_backend\\t*f_hash_backend;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_shard__init\\t*f_shard__init;\", "
	"    \"\\ttd_vmod_directors_shard__fini\\t*f_shard__fini;\", "
	"    \"\\ttd_vmod_directors_shard_set_warmup\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_set_warmup;\", "
	"    \"\\ttd_vmod_directors_shard_set_rampup\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_set_rampup;\", "
	"    \"\\ttd_vmod_directors_shard_associate\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_associate;\", "
	"    \"\\ttd_vmod_directors_shard_add_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_add_backend;\", "
	"    \"\\ttd_vmod_directors_shard_remove_backend\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_remove_backend;\", "
	"    \"\\ttd_vmod_directors_shard_clear\\t*f_shard_clear;\", "
	"    \"\\ttd_vmod_directors_shard_reconfigure\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_reconfigure;\", "
	"    \"\\ttd_vmod_directors_shard_key\\t*f_shard_key;\", "
	"    \"\\ttd_vmod_directors_shard_backend\\t*f_shard_backend;\", "
	"    \"\\ttd_vmod_directors_shard_debug\\t*f_shard_debug;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_shard_param__init\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param__init;\", "
	"    \"\\ttd_vmod_directors_shard_param__fini\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param__fini;\", "
	"    \"\\ttd_vmod_directors_shard_param_clear\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_clear;\", "
	"    \"\\ttd_vmod_directors_shard_param_set\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_set;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_by\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_by;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_key\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_key;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_alt\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_alt;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_warmup\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_warmup;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_rampup\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_rampup;\", "
	"    \"\\ttd_vmod_directors_shard_param_get_healthy\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_get_healthy;\", "
	"    \"\\ttd_vmod_directors_shard_param_use\", "
	"    \"\\t\\t\\t\\t\\t*f_shard_param_use;\", "
	"    \"\", "
	"    \"\\ttd_vmod_directors_lookup\\t*f_lookup;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_ALL;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_BLOB;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_CHOSEN;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_HASH;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_IGNORE;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_KEY;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_LAZY;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_NOW;\", "
	"    \"\\tVCL_ENUM\\t\\t\\t*enum_URL;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_directors_Func Vmod_vmod_directors_Func;\" "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"round_robin\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_round_robin\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_round_robin__init\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_round_robin__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"add_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_round_robin_add_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"remove_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_round_robin_remove_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"backend\", "
	"      [ "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_round_robin_backend\", "
	"        \"\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"fallback\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_fallback\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_fallback__init\", "
	"        \"\", "
	"        [ "
	"          \"BOOL\", "
	"          \"sticky\", "
	"          \"0\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_fallback__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"add_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_fallback_add_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"remove_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_fallback_remove_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"backend\", "
	"      [ "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_fallback_backend\", "
	"        \"\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"random\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_random\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_random__init\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_random__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"add_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_random_add_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        [ "
	"          \"REAL\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"remove_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_random_remove_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"backend\", "
	"      [ "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_random_backend\", "
	"        \"\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"hash\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_hash\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_hash__init\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_hash__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"add_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_hash_add_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        [ "
	"          \"REAL\", "
	"          \"weight\", "
	"          \"1.0\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"remove_backend\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_hash_remove_backend\", "
	"        \"\", "
	"        [ "
	"          \"BACKEND\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"backend\", "
	"      [ "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_hash_backend\", "
	"        \"\", "
	"        [ "
	"          \"STRANDS\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"shard\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_shard\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard__init\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"set_warmup\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_set_warmup\", "
	"        \"\", "
	"        [ "
	"          \"REAL\", "
	"          \"probability\", "
	"          \"0.0\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"set_rampup\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_set_rampup\", "
	"        \"\", "
	"        [ "
	"          \"DURATION\", "
	"          \"duration\", "
	"          \"0\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"associate\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_associate\", "
	"        \"\", "
	"        [ "
	"          \"BLOB\", "
	"          \"param\", "
	"          \"0\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"add_backend\", "
	"      [ "
	"        [ "
	"          \"BOOL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_add_backend\", "
	"        \"struct arg_vmod_directors_shard_add_backend\", "
	"        [ "
	"          \"BACKEND\", "
	"          \"backend\" "
	"        ], "
	"        [ "
	"          \"STRING\", "
	"          \"ident\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"DURATION\", "
	"          \"rampup\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"REAL\", "
	"          \"weight\", "
	"          null, "
	"          null, "
	"          true "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"remove_backend\", "
	"      [ "
	"        [ "
	"          \"BOOL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_remove_backend\", "
	"        \"struct arg_vmod_directors_shard_remove_backend\", "
	"        [ "
	"          \"BACKEND\", "
	"          \"backend\", "
	"          \"0\", "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"STRING\", "
	"          \"ident\", "
	"          \"0\", "
	"          null, "
	"          true "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"clear\", "
	"      [ "
	"        [ "
	"          \"BOOL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_clear\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"reconfigure\", "
	"      [ "
	"        [ "
	"          \"BOOL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_reconfigure\", "
	"        \"\", "
	"        [ "
	"          \"INT\", "
	"          \"replicas\", "
	"          \"67\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"key\", "
	"      [ "
	"        [ "
	"          \"INT\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_key\", "
	"        \"\", "
	"        [ "
	"          \"STRANDS\" "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"backend\", "
	"      [ "
	"        [ "
	"          \"BACKEND\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_backend\", "
	"        \"struct arg_vmod_directors_shard_backend\", "
	"        [ "
	"          \"ENUM\", "
	"          \"by\", "
	"          \"HASH\", "
	"          [ "
	"            \"HASH\", "
	"            \"URL\", "
	"            \"KEY\", "
	"            \"BLOB\" "
	"          ], "
	"          true "
	"        ], "
	"        [ "
	"          \"INT\", "
	"          \"key\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"BLOB\", "
	"          \"key_blob\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"INT\", "
	"          \"alt\", "
	"          \"0\", "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"REAL\", "
	"          \"warmup\", "
	"          \"-1\", "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"BOOL\", "
	"          \"rampup\", "
	"          \"1\", "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"ENUM\", "
	"          \"healthy\", "
	"          \"CHOSEN\", "
	"          [ "
	"            \"CHOSEN\", "
	"            \"IGNORE\", "
	"            \"ALL\" "
	"          ], "
	"          true "
	"        ], "
	"        [ "
	"          \"BLOB\", "
	"          \"param\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"ENUM\", "
	"          \"resolve\", "
	"          null, "
	"          [ "
	"            \"NOW\", "
	"            \"LAZY\" "
	"          ], "
	"          true "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"debug\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_debug\", "
	"        \"\", "
	"        [ "
	"          \"INT\" "
	"        ] "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$OBJ\", "
	"    \"shard_param\", "
	"    { "
	"      \"NULL_OK\": false "
	"    }, "
	"    \"struct vmod_directors_shard_param\", "
	"    [ "
	"      \"$INIT\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param__init\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$FINI\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param__fini\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"clear\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_clear\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$RESTRICT\", "
	"      [ "
	"        \"vcl_pipe\", "
	"        \"backend\", "
	"        \"housekeeping\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"set\", "
	"      [ "
	"        [ "
	"          \"VOID\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_set\", "
	"        \"struct arg_vmod_directors_shard_param_set\", "
	"        [ "
	"          \"ENUM\", "
	"          \"by\", "
	"          null, "
	"          [ "
	"            \"HASH\", "
	"            \"URL\", "
	"            \"KEY\", "
	"            \"BLOB\" "
	"          ], "
	"          true "
	"        ], "
	"        [ "
	"          \"INT\", "
	"          \"key\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"BLOB\", "
	"          \"key_blob\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"INT\", "
	"          \"alt\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"REAL\", "
	"          \"warmup\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"BOOL\", "
	"          \"rampup\", "
	"          null, "
	"          null, "
	"          true "
	"        ], "
	"        [ "
	"          \"ENUM\", "
	"          \"healthy\", "
	"          null, "
	"          [ "
	"            \"CHOSEN\", "
	"            \"IGNORE\", "
	"            \"ALL\" "
	"          ], "
	"          true "
	"        ] "
	"      ] "
	"    ], "
	"    [ "
	"      \"$RESTRICT\", "
	"      [ "
	"        \"vcl_pipe\", "
	"        \"backend\", "
	"        \"housekeeping\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_by\", "
	"      [ "
	"        [ "
	"          \"STRING\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_by\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_key\", "
	"      [ "
	"        [ "
	"          \"INT\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_key\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_alt\", "
	"      [ "
	"        [ "
	"          \"INT\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_alt\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_warmup\", "
	"      [ "
	"        [ "
	"          \"REAL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_warmup\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_rampup\", "
	"      [ "
	"        [ "
	"          \"BOOL\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_rampup\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"get_healthy\", "
	"      [ "
	"        [ "
	"          \"STRING\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_get_healthy\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$METHOD\", "
	"      \"use\", "
	"      [ "
	"        [ "
	"          \"BLOB\" "
	"        ], "
	"        \"Vmod_vmod_directors_Func.f_shard_param_use\", "
	"        \"\" "
	"      ] "
	"    ], "
	"    [ "
	"      \"$RESTRICT\", "
	"      [ "
	"        \"vcl_pipe\", "
	"        \"backend\", "
	"        \"housekeeping\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"lookup\", "
	"    [ "
	"      [ "
	"        \"BACKEND\" "
	"      ], "
	"      \"Vmod_vmod_directors_Func.f_lookup\", "
	"      \"\", "
	"      [ "
	"        \"STRING\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$RESTRICT\", "
	"    [ "
	"      \"housekeeping\" "
	"    ] "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_directors_Data) */
/*lint -esym(759, Vmod_directors_Data) */
/*lint -esym(765, Vmod_directors_Data) */

extern const struct vmod_data Vmod_directors_Data;

const struct vmod_data Vmod_directors_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"edab1c2b46260ba7857d12e0b786d29b78460cd930959505a67272486eac4683",
	.name =		"directors",
	.func_name =	"Vmod_vmod_directors_Func",
	.func =		&Vmod_vmod_directors_Func,
	.func_len =	sizeof(Vmod_vmod_directors_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
