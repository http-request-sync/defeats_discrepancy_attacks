/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit ./vmod_cookie.vcc and run make instead
 */

#include "config.h"
#include "vdef.h"
#include "vrt.h"
#include "vcc_cookie_if.h"
#include "vmod_abi.h"


typedef VCL_VOID td_vmod_cookie_clean(VRT_CTX,
    struct vmod_priv *);
typedef VCL_VOID td_vmod_cookie_delete(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_VOID td_vmod_cookie_filter(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_VOID td_vmod_cookie_filter_re(VRT_CTX,
    struct vmod_priv *, VCL_REGEX);
typedef VCL_VOID td_vmod_cookie_keep(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_VOID td_vmod_cookie_keep_re(VRT_CTX,
    struct vmod_priv *, VCL_REGEX);
typedef VCL_STRING td_vmod_cookie_format_date(VRT_CTX, VCL_TIME,
    VCL_DURATION);
typedef VCL_STRING td_vmod_cookie_get(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_STRING td_vmod_cookie_get_re(VRT_CTX,
    struct vmod_priv *, VCL_REGEX);
typedef VCL_STRING td_vmod_cookie_get_string(VRT_CTX,
    struct vmod_priv *);
typedef VCL_BOOL td_vmod_cookie_isset(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_VOID td_vmod_cookie_parse(VRT_CTX,
    struct vmod_priv *, VCL_STRING);
typedef VCL_VOID td_vmod_cookie_set(VRT_CTX, struct vmod_priv *,
    VCL_STRING, VCL_STRING);

struct Vmod_vmod_cookie_Func {
	td_vmod_cookie_clean		*f_clean;
	td_vmod_cookie_delete		*f_delete;
	td_vmod_cookie_filter		*f_filter;
	td_vmod_cookie_filter_re	*f_filter_re;
	td_vmod_cookie_keep		*f_keep;
	td_vmod_cookie_keep_re		*f_keep_re;
	td_vmod_cookie_format_date	*f_format_date;
	td_vmod_cookie_get		*f_get;
	td_vmod_cookie_get_re		*f_get_re;
	td_vmod_cookie_get_string	*f_get_string;
	td_vmod_cookie_isset		*f_isset;
	td_vmod_cookie_parse		*f_parse;
	td_vmod_cookie_set		*f_set;
};

/*lint -esym(754, Vmod_vmod_cookie_Func::*) */

static const struct Vmod_vmod_cookie_Func Vmod_vmod_cookie_Func = {
	.f_clean =			vmod_clean,
	.f_delete =			vmod_delete,
	.f_filter =			vmod_filter,
	.f_filter_re =			vmod_filter_re,
	.f_keep =			vmod_keep,
	.f_keep_re =			vmod_keep_re,
	.f_format_date =		vmod_format_date,
	.f_get =			vmod_get,
	.f_get_re =			vmod_get_re,
	.f_get_string =			vmod_get_string,
	.f_isset =			vmod_isset,
	.f_parse =			vmod_parse,
	.f_set =			vmod_set,

};
#define STRINGIFY3(arg) #arg
#define STRINGIFY2(arg) STRINGIFY3(#arg)
#define STRINGIFY1(arg) STRINGIFY2(arg)

static const char Vmod_Json[] = {
	"VMOD_JSON_SPEC"
	"[ "
	"  [ "
	"    \"$VMOD\", "
	"    \"1.0\", "
	"    \"cookie\", "
	"    \"Vmod_vmod_cookie_Func\", "
	"    \"4e6b575e5b29a49555cf5a1a842ef310f4bf9b526a25a8c3c815a07348ec1c27\" ,"
	"    \"" VMOD_ABI_Version "\", "
	    STRINGIFY1(0) ", "
	    STRINGIFY1(0)
	"  ], "
	"  [ "
	"    \"$CPROTO\", "
	"    \"#define VPFX(a) vmod_##a\", "
	"    \"#define VARGS(a) arg_vmod_cookie_##a\", "
	"    \"#define VENUM(a) enum_vmod_cookie_##a\", "
	"    \"//lint -esym(755, VPFX)\", "
	"    \"//lint -esym(767, VPFX)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(767, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"//lint -esym(767, VENUM)\", "
	"    \"//lint -esym(755, VARGS)\", "
	"    \"//lint -esym(755, VENUM)\", "
	"    \"\", "
	"    \"/* Functions */\", "
	"    \"typedef VCL_VOID td_vmod_cookie_clean(VRT_CTX,\", "
	"    \"    struct vmod_priv *);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_delete(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_filter(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_filter_re(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_REGEX);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_keep(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_keep_re(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_REGEX);\", "
	"    \"typedef VCL_STRING td_vmod_cookie_format_date(VRT_CTX, VCL_TIME,\", "
	"    \"    VCL_DURATION);\", "
	"    \"typedef VCL_STRING td_vmod_cookie_get(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_STRING td_vmod_cookie_get_re(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_REGEX);\", "
	"    \"typedef VCL_STRING td_vmod_cookie_get_string(VRT_CTX,\", "
	"    \"    struct vmod_priv *);\", "
	"    \"typedef VCL_BOOL td_vmod_cookie_isset(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_parse(VRT_CTX,\", "
	"    \"    struct vmod_priv *, VCL_STRING);\", "
	"    \"typedef VCL_VOID td_vmod_cookie_set(VRT_CTX, struct vmod_priv *,\", "
	"    \"    VCL_STRING, VCL_STRING);\", "
	"    \"\", "
	"    \"struct Vmod_vmod_cookie_Func {\", "
	"    \"\\ttd_vmod_cookie_clean\\t\\t*f_clean;\", "
	"    \"\\ttd_vmod_cookie_delete\\t\\t*f_delete;\", "
	"    \"\\ttd_vmod_cookie_filter\\t\\t*f_filter;\", "
	"    \"\\ttd_vmod_cookie_filter_re\\t*f_filter_re;\", "
	"    \"\\ttd_vmod_cookie_keep\\t\\t*f_keep;\", "
	"    \"\\ttd_vmod_cookie_keep_re\\t\\t*f_keep_re;\", "
	"    \"\\ttd_vmod_cookie_format_date\\t*f_format_date;\", "
	"    \"\\ttd_vmod_cookie_get\\t\\t*f_get;\", "
	"    \"\\ttd_vmod_cookie_get_re\\t\\t*f_get_re;\", "
	"    \"\\ttd_vmod_cookie_get_string\\t*f_get_string;\", "
	"    \"\\ttd_vmod_cookie_isset\\t\\t*f_isset;\", "
	"    \"\\ttd_vmod_cookie_parse\\t\\t*f_parse;\", "
	"    \"\\ttd_vmod_cookie_set\\t\\t*f_set;\", "
	"    \"};\", "
	"    \"#undef VPFX\", "
	"    \"#undef VARGS\", "
	"    \"#undef VENUM\", "
	"    \"static struct Vmod_vmod_cookie_Func Vmod_vmod_cookie_Func;\" "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"clean\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_clean\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"delete\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_delete\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"cookiename\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"filter\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_filter\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"filterstring\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"filter_re\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_filter_re\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"REGEX\", "
	"        \"expression\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"keep\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_keep\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"filterstring\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"keep_re\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_keep_re\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"REGEX\", "
	"        \"expression\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"format_date\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_format_date\", "
	"      \"\", "
	"      [ "
	"        \"TIME\", "
	"        \"now\" "
	"      ], "
	"      [ "
	"        \"DURATION\", "
	"        \"timedelta\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"get\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_get\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"cookiename\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"get_re\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_get_re\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"REGEX\", "
	"        \"expression\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"get_string\", "
	"    [ "
	"      [ "
	"        \"STRING\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_get_string\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"isset\", "
	"    [ "
	"      [ "
	"        \"BOOL\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_isset\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"cookiename\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"parse\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_parse\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"cookieheader\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$FUNC\", "
	"    \"set\", "
	"    [ "
	"      [ "
	"        \"VOID\" "
	"      ], "
	"      \"Vmod_vmod_cookie_Func.f_set\", "
	"      \"\", "
	"      [ "
	"        \"PRIV_TASK\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"cookiename\" "
	"      ], "
	"      [ "
	"        \"STRING\", "
	"        \"value\" "
	"      ] "
	"    ] "
	"  ], "
	"  [ "
	"    \"$ALIAS\", "
	"    \"format_rfc1123\", "
	"    \"format_date\" "
	"  ] "
	"] "
	"\n\x03"
};
#undef STRINGIFY

/*lint -esym(714, Vmod_cookie_Data) */
/*lint -esym(759, Vmod_cookie_Data) */
/*lint -esym(765, Vmod_cookie_Data) */

extern const struct vmod_data Vmod_cookie_Data;

const struct vmod_data Vmod_cookie_Data = {
	.vrt_major =	0,
	.vrt_minor =	0,
	.file_id =	"4e6b575e5b29a49555cf5a1a842ef310f4bf9b526a25a8c3c815a07348ec1c27",
	.name =		"cookie",
	.func_name =	"Vmod_vmod_cookie_Func",
	.func =		&Vmod_vmod_cookie_Func,
	.func_len =	sizeof(Vmod_vmod_cookie_Func),
	.json =		Vmod_Json,
	.abi =		VMOD_ABI_Version,
};
