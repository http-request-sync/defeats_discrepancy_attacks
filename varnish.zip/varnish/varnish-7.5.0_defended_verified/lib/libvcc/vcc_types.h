/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run lib/libvcc/generate.py instead.
 */

/*lint -save -e525 -e539 */

VCC_TYPE(ACL, acl)
VCC_TYPE(BACKEND, backend)
VCC_TYPE(BLOB, blob)
VCC_TYPE(BODY, body)
VCC_TYPE(BOOL, bool)
VCC_TYPE(BYTES, bytes)
VCC_TYPE(DURATION, duration)
VCC_TYPE(ENUM, enum)
VCC_TYPE(HEADER, header)
VCC_TYPE(HTTP, http)
VCC_TYPE(INSTANCE, instance)
VCC_TYPE(INT, int)
VCC_TYPE(IP, ip)
VCC_TYPE(PROBE, probe)
VCC_TYPE(REAL, real)
VCC_TYPE(REGEX, regex)
VCC_TYPE(STEVEDORE, stevedore)
VCC_TYPE(STRANDS, strands)
VCC_TYPE(STRING, string)
VCC_TYPE(STRINGS, strings)
VCC_TYPE(SUB, sub)
VCC_TYPE(TIME, time)
VCC_TYPE(VCL, vcl)
VCC_TYPE(VOID, void)
#undef VCC_TYPE

/*lint -restore */
