/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run lib/libvcc/generate.py instead.
 */

#define	CBLOB 128
#define	CNUM 129
#define	CSRC 130
#define	CSTR 131
#define	EOI 132
#define	FNUM 133
#define	ID 134
#define	T_CAND 135
#define	T_COR 136
#define	T_DEC 137
#define	T_DECR 138
#define	T_DIV 139
#define	T_EQ 140
#define	T_GEQ 141
#define	T_INC 142
#define	T_INCR 143
#define	T_LEQ 144
#define	T_MUL 145
#define	T_NEQ 146
#define	T_NOMATCH 147
#define	T_SHL 148
#define	T_SHR 149
