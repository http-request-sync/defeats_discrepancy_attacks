..
	Copyright (c) 2017 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

..
	This is *NOT* a RST file but the syntax has been chosen so
	that it may become an RST file at some later date.

..
	varnish_vsc_begin:: smu

SMU – Umem Stevedore Counters
=============================

``c_req`` – `counter` - info

	Allocator requests

	Number of times the storage has been asked to provide a storage segment.

``c_fail`` – `counter` - info

	Allocator failures

	Number of times the storage has failed to provide a storage segment.

``c_bytes`` – `counter` - info

	Bytes allocated

	Number of total bytes allocated by this storage.

``c_freed`` – `counter` - info

	Bytes freed

	Number of total bytes returned to this storage.

``g_alloc`` – `gauge` - info

	Allocations outstanding

	Number of storage allocations outstanding.

``g_bytes`` – `gauge` - info

	Bytes outstanding

	Number of bytes allocated from the storage.

``g_space`` – `gauge` - info

	Bytes available

	Number of bytes left in the storage.

..
	varnish_vsc_end:: smu
