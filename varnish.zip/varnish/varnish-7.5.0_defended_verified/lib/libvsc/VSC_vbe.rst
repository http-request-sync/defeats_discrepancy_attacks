..
	Copyright (c) 2017-2021 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

..
	This is *NOT* a RST file but the syntax has been chosen so
	that it may become an RST file at some later date.

..
	varnish_vsc_begin:: vbe

VBE – Backend Counters
======================

``happy`` – `bitmap` - info

	Happy health probes

	Represents the last probe results as a bitmap. Happy probes are bits set
	to 1, and the unhappy ones are set to 0. The highest bits represent the
	oldest probes.

``bereq_hdrbytes`` – `counter` - info

	Request header bytes

	Total backend request header bytes sent

``bereq_bodybytes`` – `counter` - info

	Request body bytes

	Total backend request body bytes sent

``beresp_hdrbytes`` – `counter` - info

	Response header bytes

	Total backend response header bytes received

``beresp_bodybytes`` – `counter` - info

	Response body bytes

	Total backend response body bytes received

``pipe_hdrbytes`` – `counter` - info

	Pipe request header bytes

	Total request bytes sent for piped sessions

``pipe_out`` – `counter` - info

	Piped bytes to backend

	Total number of bytes forwarded to backend in pipe sessions

``pipe_in`` – `counter` - info

	Piped bytes from backend

	Total number of bytes forwarded from backend in pipe sessions

``conn`` – `gauge` - info

	Concurrent connections used

	The number of currently used connections to the backend. This
	number is always less or equal to the number of connections to
	the backend (as, for example shown as ESTABLISHED for TCP
	connections in netstat) due to connection pooling.

``req`` – `counter` - info

	Backend requests sent

``unhealthy`` – `counter` - info

	Fetches not attempted due to backend being unhealthy

``busy`` – `counter` - info

	Fetches not attempted due to backend being busy

	Number of times the max_connections limit was reached

..
	=== Anything below is actually per VCP entry, but collected per
	=== backend for simplicity

``fail`` – `counter` - info

	Connections failed

	Counter of failed opens. Detailed reasons are given in the
	fail_* counters (DIAG level) and in the log under the FetchError tag.

	This counter is the sum of all detailed fail_* counters.

	All fail_* counters may be slightly inaccurate for efficiency.

``fail_eacces`` – `counter` - diag

	Connections failed with EACCES or EPERM

``fail_eaddrnotavail`` – `counter` - diag

	Connections failed with EADDRNOTAVAIL

``fail_econnrefused`` – `counter` - diag

	Connections failed with ECONNREFUSED

``fail_enetunreach`` – `counter` - diag

	Connections failed with ENETUNREACH

``fail_etimedout`` – `counter` - diag

	Connections failed ETIMEDOUT

``fail_other`` – `counter` - diag

	Connections failed for other reason

``helddown`` – `counter` - diag

	Connection opens not attempted

	Connections not attempted during the backend_local_error_holddown
	or backend_remote_error_holddown interval after a fundamental
	connection issue.

..
	varnish_vsc_end:: vbe
