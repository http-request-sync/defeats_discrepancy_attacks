..
	Copyright (c) 2017 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

..
	This is *NOT* a RST file but the syntax has been chosen so
	that it may become an RST file at some later date.

..
	varnish_vsc_begin:: mgt

MGT – Management Process Counters
=================================

``uptime`` – `counter` - info

	Management process uptime

	Uptime in seconds of the management process

``child_start`` – `counter` - diag

	Child process started

	Number of times the child process has been started

``child_exit`` – `counter` - diag

	Child process normal exit

	Number of times the child process has been cleanly stopped

``child_stop`` – `counter` - diag

	Child process unexpected exit

	Number of times the child process has exited with an
	unexpected return code

``child_died`` – `counter` - diag

	Child process died (signal)

	Number of times the child process has died due to signals

``child_dump`` – `counter` - diag

	Child process core dumped

	Number of times the child process has produced core dumps

``child_panic`` – `counter` - diag

	Child process panic

	Number of times the management process has caught a child panic

..
	varnish_vsc_end:: mgt
