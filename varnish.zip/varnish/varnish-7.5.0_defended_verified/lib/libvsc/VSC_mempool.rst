..
	Copyright (c) 2017 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

..
	This is *NOT* a RST file but the syntax has been chosen so
	that it may become an RST file at some later date.

..
	varnish_vsc_begin:: mempool

MEMPOOL – Memory Pool Counters
==============================

``live`` – `gauge` - debug

	In use


``pool`` – `gauge` - debug

	In Pool


``sz_wanted`` – `gauge` - debug

	Size requested


``sz_actual`` – `gauge` - debug

	Size allocated


``allocs`` – `counter` - debug

	Allocations

``frees`` – `counter` - debug

	Frees

``recycle`` – `counter` - debug

	Recycled from pool


``timeout`` – `counter` - debug

	Timed out from pool


``toosmall`` – `counter` - debug

	Too small to recycle


``surplus`` – `counter` - debug

	Too many for pool


``randry`` – `counter` - debug

	Pool ran dry


..
	varnish_vsc_end:: mempool
