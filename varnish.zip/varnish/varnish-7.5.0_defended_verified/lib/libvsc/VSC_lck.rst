..
	Copyright (c) 2017-2019 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

..
	This is *NOT* a RST file but the syntax has been chosen so
	that it may become an RST file at some later date.

..
	varnish_vsc_begin:: lck

LCK – Lock Counters
===================

	Counters which track the activity in the different classes
	of mutex-locks.

	The counts may be slightly wrong if there are more than one
	lock instantiated in each class (ie: .creat > 1)

``creat`` – `counter` - debug

	Created locks


``destroy`` – `counter` - debug

	Destroyed locks


``locks`` – `counter` - debug

	Lock Operations


``dbg_busy`` – `counter` - debug

	Contended lock operations

	If the ``lck`` debug bit is set: Lock operations which
	returned EBUSY on the first locking attempt.

	If the ``lck`` debug bit is unset, this counter will never be
	incremented even if lock operations are contended.

``dbg_try_fail`` – `counter` - debug

	Contended trylock operations

	If the ``lck`` debug bit is set: Trylock operations which
	returned EBUSY.

	If the ``lck`` debug bit is unset, this counter will never be
	incremented even if lock operations are contended.

..
	varnish_vsc_end:: lck

